exports.handler = require('./lib/index').handler
